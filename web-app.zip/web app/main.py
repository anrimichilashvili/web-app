from flask import Flask, redirect, url_for, render_template, request, session
from flask_sqlalchemy import SQLAlchemy
import os
from flask import flash



app = Flask(__name__)
app.secret_key = "hello"
db_path = os.path.join(os.path.dirname(__file__), 'movies_ranking.sqlite')
db_uri = 'sqlite:///{}'.format(db_path)
app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True
db= SQLAlchemy(app)


class movies(db.Model):
    id = db.Column("ID", db.INTEGER, primary_key=True)
    film = db.Column("Film", db.String(50))
    genre = db.Column("Genre", db.String(100))
    leadstudio = db.Column("LeadStudio", db.String(70))
    worldwidegross = db.Column("WorldwideGross", db.Float)
    year = db.Column("Year", db.INTEGER)

    def __str__(self):
        return f'{self.id}.Film name is: {self.film}; Genre: {self.genre}; leads tudio is: {self.leadstudio}; ' \
               f'wordl wide gross: {self.worldwidegross} year: {self.year}'



@app.route('/')
def home():
    all_films = movies.query.all()
    return render_template('index.html', all_films = all_films)


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        session['username'] = username
        return redirect(url_for('user'))

    return render_template('login.html')



@app.route('/user')
def user():
    return render_template('user.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    return render_template('index.html')


@app.route('/films', methods=['GET', 'POST'])
def films():
    if request.method == 'POST':
        f = request.form['film']
        g = request.form['genre']
        l = request.form['leadstudio']
        w = request.form['worldwidegross']
        y = request.form['year']
        if f=='' or g==''or l=='' or w=='' or y=='':
            flash("შეიტანეთ ყველა ველი", 'error')
        elif not w.isascii() or not y.isnumeric():
            flash('შეიყვანეთ რიხვითი მნიშვნელობა ბოლო ორ განყოფილებაში', 'error')
        else:
            b1 = movies(film = f, genre = g, leadstudio = l, worldwidegross = '20.12', year = '1995')

            db.session.add(b1)
            db.session.commit()
            flash( "მონაცემები დამატებულია", 'info')
    return render_template('films.html')


if __name__ == "__main__":
    app.run(debug=True)